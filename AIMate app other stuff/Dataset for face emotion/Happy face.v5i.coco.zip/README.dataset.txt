# Happy face > 2023-06-22 3:32pm
https://universe.roboflow.com/project-fjp7n/happy-face-pkgvd

Provided by a Roboflow user
License: CC BY 4.0

